<?php if(is_active_sidebar("primary_sidebar")) :?>

<div class="plaintext_first_sidebar">
	<?php dynamic_sidebar('primary_sidebar'); ?>
</div>

<?php endif; ?>