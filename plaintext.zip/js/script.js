jQuery(document).ready(function () {
	jQuery('header .wrapper .links #cssmenu').meanmenu({meanScreenWidth:580});
});